# BMD Feed B Broadcaster: Configuração para múltiplos canais

**A configuração para múltiplos canais contém três pontos principais:**

1. Nome da instância e diretórios
   - Sigla da aplicação, nesse caso FBB, seguido por um *underline* e o número da instância. Neste exemplo, temos uma instância de número 999 da aplicação Feed B Broadcaster (FBB) configurada para os canais 1 e 55 -> FBB_999.json e FBB_999.scr.
   - Exemplo do diretório da aplicação: /App/channels/FBB_999/bin/bmd-feedb-broadcaster-\<VERSION\>-SNAPSHOT.jar

2. Arquivo de configuração
   - Os canais serão configurados e mapeados na aplicação Java como uma estrutura List\<ChannelConfiguration\>, ou seja, uma lista com objetos do tipo ChannelConfiguration, que por sua vez um atributo short channelNo (número do canal), um objeto do tipo InboundListenerConfiguration (Configuração do TIBCO) e um objeto do tipo UDPTransportChannelInterfaceConfiguration (Configuração do UDP Multicast).

3. Métricas HDR
    - As métricas HDR serão automaticamente separadas em arquivos distintos por canal dentro do diretótio /App/log da aplicação com o nome no formato *\<NOME DA INSTÂNCIA\>_hdr_metrics-CH\<NUMERO DO CANAL\>.log*

#### Exemplo de arquivo de configuração do Feed B Broadcaster para atender aos canais 1 e 55:

> FBB_999.json
>
>{
>    
> "configuredChannels": [ 
> 
> **Configuração do Canal 1**
> > ```
> > {
> >   "channelNo": 1,                                                                                                 
> >    "inboundListener": {                                             
> >      "type": "tibrv",                                             
> >      "tibrvConfiguration": {                                                                                                                                       
> >        "service": "8001",                                             
> >        "network": "p2p2;239.90.8.1;239.90.8.1",                                             
> >        "daemon": "tcp:9025",                                             
> >        "callbackInstanceName": "upperbus",                                             
> >        "subjects": [                                             
> >          "FA_BMD.MD_01"                                             
> >        ]                                             
> >      }                                             
> >    },                                             
> >    "udpTransportInterfaceConfiguration": {                                            
> >      "port": 50111,                                             
> >      "ipAddress": "239.90.8.111",                                             
> >      "networkInterface": "p2p2"                                           
> >    }                                             
> >  },    
> > ```
>  **Configuração do Canal 55**
> > ```
> > {
> >    "channelNo": 55,                                                 
> >    "inboundListener": {
> >      "type": "tibrv",
> >      "tibrvConfiguration": {
> >        "service": "8055",
> >        "network": "p2p2;239.90.8.55;239.90.8.55",
> >        "daemon": "tcp:9025",
> >        "callbackInstanceName": "upperbus",
> >        "subjects": [
> >          "FA_BMD.MD_55"
> >        ]
> >      }
> >    },
> >    "udpTransportInterfaceConfiguration": {
> >      "port": 50155,
> >      "ipAddress": "239.90.8.155",
> >      "networkInterface": "p2p2"
> >    }
> > }
> > ```
> ],
>
>  **Configurações comuns para o tibrv**
> ```
>  "tibrvCommonsConfiguration": {
>    "tibrvLibraryImplementationType": 2
>  },
> ```
>  **Configurações comuns para o udpTransport**
> ```
>  "udpTransportCommonsConfiguration": {
>    "timeToLive": 100,
>    "packetSize": 1400,
>    "sendBuffer": 0
>  },
> ```
>  **Configuração da fila de pacotes e das métricas**
> ```
>  "packetQueueConfiguration": {
>    "bufferSize": 2048,
>    "largeBufferSize": 131072,
>    "initialBufferPoolCount": 1024,
>    "capacity": 16384
>  },
>  "metricConfiguration": {
>    "logLevel": "ESSENTIAL",
>    "writeInterval": 1000,
>    "hdrPrecision": 2
>  },
> ```
>  **Configurações do logger para as métricas separadas por canal**
> ```
>  "loggerExtenderConfiguration": {
>    "messagePattern": "%msg",
>    "timeTriggeringInterval": 1,
>    "timeTriggeringModulation": true,
>    "sizeTriggering": "100MB",
>    "maxFilesToKeep": "1000",
>    "fileImmediateFlush": true,
>    "fileAppend": true
>  },
> ```
>  **Configurações do mecanismo de fault tolerance (FT)**
> ```
>  "faultTolerance": {
>    "ftGroupName": "${instance_name}",
>    "ftHeartBeatInterval": 2,
>    "ftActivationInterval": 10,
>    "incrementalTimeout": 3000,
>    "publishedTakeoverTimeout": 1000,
>    "service": "30999",
>    "network": "127.0.0.1;",
>    "daemon": "tcp:9025"
>  }
>  ```
>}
