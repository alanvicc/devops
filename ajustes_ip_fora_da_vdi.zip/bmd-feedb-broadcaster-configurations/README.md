# BMD Feed B Broadcaster Configurations

Projeto contendo as configurações do BMD Feed B Broadcaster de todos os ambientes.

Há um diretório para cada ambiente, todos esses diretórios serão copiados para o servidor no momento do deploy. O último passo do deploy é copiar todos os arquivos que estiverem abaixo do diretório do ambiente + todos os arquivos abaixo do diretório ambiente/host para dentro do diretório cfg da aplicação.

Exemplo:
Digamos que estamos implantando no ambiente "dev" nas máquinas 'pmatrd06301d' e 'pmatrd06401d', e a estrutura do bmd-feeedb-broadcaster-configurations é a seguinte:
```
+-- dev
|   +-- java.3pr
|   +-- rv.3pr
|   +-- log4j2.xml
|   +-- pmatrd06301d
|   +-- instances.csv
|   |   +-- FBB_001.json
|   |   +-- FBB_001.scr
|   +-- pmatrd06401d
|   |   +-- FBB_002.json
|   |   +-- FBB_002.scr
+-- prod
|   +-- ..
|   +-- MQ1
|   |   +-- ..
|   |   +-- ..
|   +-- MQ2
|   |   +-- ..
|   |   +-- ..
+-- cert
|   +-- ..
|   +-- ..
```

Serão copiados para o diretório cfg da aplicação:
- os arquivos java.3pr, rv.3pr, log4j2.xml (comuns para todas as máquinas)
- os arquivos FBB_001.scr e FBB_001.json na máquina pmatrd06301d
- os arquivos FBB_002.scr e FBB_002.json na máquina pmatrd06401d

Será copiado para o diretório raiz (App) da aplicação:
- o arquivo instances.csv
--------------------------------------------------------------------------------------------
Estrutura da aplicação em uma máquina:
```
+-- App
|   +-- instances.csv
|   +-- cfg
|   |   +-- java.3pr
|   |   +-- rv.3pr
|   |   +-- log4j2.xml
|   |   +-- FBB_001.json
|   |   +-- FBB_001.scr
|   +-- channels
|   |   +-- FBB_001
|   |   |   +-- bin
|   |   |   |   +-- bmd-feedb-broadcaster-<VERSION>-SNAPSHOT.jar
|   |   |   +-- lib
|   |   |   |   +-- log4j-api-<VERSION_LOG4J>.jar
|   |   |   |   +-- log4j-core-<VERSION_LOG4J>.jar
|   |   |   |   +-- log4j-slf4j-impl-<VERSION_LOG4J>.jar
|   |   |   +-- scripts
|   |   |   |   +-- startInstance
|   +-- log
|   +-- output
|   +-- scripts
|   |   +-- is-primary.sh
|   |   +-- seeall
|   |   +-- startall
|   |   +-- startInstance
|   |   +-- startJava
|   |   +-- startRecovery
|   |   +-- stopall
|   |   +-- stopJava
|   |   +-- utils.sh
```