# BMD Snapshot Configurations

Projeto contendo as configurações do BMD Snapshot de todos os ambientes.

Há um diretório para cada ambiente, todos esses diretórios serão copiados para o servidor no momento do deploy. O ultimo passo do deploy é copiar todos os arquivos que estiverem abaixo do diretório do ambiente + todos os arquivos embaixo do diretório ambiente/host para dentro do diretório cfg da aplicação.

Exemplo:
Digamos que estamos implantando no ambiente "prod" nas máquinas MDBTRD00101P e MDBTRD00102P, e a estrutura do bmd-snapshot-configurations é a seguinte:
```
+-- dev
|   +-- ..
|   +-- ..
+-- prod
|   +-- log4j2.xml
|   +-- java.3pr
|   +-- rv.3pr
|   +-- instances.csv
|   +-- mdbtrd00101p
|   |   +-- BSA_068.scr
|   |   +-- BSA_068.json
|   +-- mdbtrd00102p
|   |   +-- BSA_070.scr
|   |   +-- BSA_070.json
+-- cert
|   +-- ..
|   +-- ..
```

Será copiado para o diretório diretorio raiz da aplicação:
- o arquivo instances.csv nas duas máquinas (MDBTRD00101P e MDBTRD00102P)

Serão copiados para o diretório cfg da aplicação:
- o arquivo log4j2.xml nas duas máquinas (MDBTRD00101P e MDBTRD00102P)
- os arquivos BSA_068.scr e BSA_068.json na máquina MDBTRD00101P
- os arquivos BSA_070.scr e BSA_070.json na máquina MDBTRD00102P
- os 2 arquivos .3pr (java.3pr e rv.3pr)